﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Accueil_Bibliotheque_Maladie_A_Z : Form
    {
        MySqlConnection connection;
        public Accueil_Bibliotheque_Maladie_A_Z()
        {
            InitializeComponent();
        }

        private void deconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Accueil_Bibliotheque_Maladie_A_Z_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server=10.101.0.1; database=projetb2s4; uid=Marius; pwd=Marius1998%");
            connection.Open();
            MySqlCommand requete = new MySqlCommand();
            requete.Connection = connection;
            requete.CommandText = "SELECT * FROM Maladie ORDER BY Nom_Maladie ASC";
            MySqlDataReader maladie = requete.ExecuteReader();
            while(maladie.Read())
            {
                dataGridView1.Rows.Add(maladie["Nom_Maladie"]);
            }

            connection.Close();
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            var accueil_bibliotheque_maladie = new Accueil_Bibliotheque_Maladie();
            accueil_bibliotheque_maladie.Show();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            connection.Open();
            dataGridView1.Rows.Clear();
            MySqlCommand requete = new MySqlCommand();
            requete.Connection = connection;
            requete.CommandText = "SELECT * FROM Maladie WHERE Nom_Maladie LIKE '%"+textBox1.Text+"%'";
            MySqlDataReader maladie_recherche = requete.ExecuteReader();
            while(maladie_recherche.Read())
            {
                dataGridView1.Rows.Add(maladie_recherche["Nom_Maladie"]);
            }
            connection.Close();
        }

        private void maladieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_maladie = new Ajouter_Maladie();
            ajouter_maladie.ShowDialog();
        }

        private void symptômeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_symptome = new Ajouter_Symptome();
            ajouter_symptome.ShowDialog();
        }
    }
}
