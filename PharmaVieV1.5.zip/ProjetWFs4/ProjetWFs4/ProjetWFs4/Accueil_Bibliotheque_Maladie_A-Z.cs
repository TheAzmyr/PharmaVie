﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Accueil_Bibliotheque_Maladie_A_Z : Form
    {
        MySqlConnection connection;
        public Accueil_Bibliotheque_Maladie_A_Z()
        {
            InitializeComponent();
        }

        private void deconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Accueil_Bibliotheque_Maladie_A_Z_Load(object sender, EventArgs e)
        {
            // connection = new MySqlConnection("server=10.101.0.1; database=PharmaVie; uid=root; pwd=rootroot");
            connection = new MySqlConnection("server=localhost; database=pharmavie; uid=root; pwd=");
            connection.Open();
            MySqlCommand requete = new MySqlCommand();
            requete.Connection = connection;
            requete.CommandText = "SELECT * FROM Maladie ORDER BY Nom_Maladie ASC";
            MySqlDataReader maladie = requete.ExecuteReader();
            while(maladie.Read())
            {
                dataGridView1.Rows.Add(maladie["Nom_Maladie"]);
            }

            connection.Close();
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            var accueil_bibliotheque_maladie = new Accueil_Bibliotheque_Maladie();
            accueil_bibliotheque_maladie.Show();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            connection.Open();
            dataGridView1.Rows.Clear();
            MySqlCommand requete = new MySqlCommand();
            requete.Connection = connection;
            requete.CommandText = "SELECT * FROM Maladie WHERE Nom_Maladie LIKE '%"+textBox1.Text+"%'";
            MySqlDataReader maladie_recherche = requete.ExecuteReader();
            while(maladie_recherche.Read())
            {
                dataGridView1.Rows.Add(maladie_recherche["Nom_Maladie"]);
            }
            connection.Close();
        }

        private void maladieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_maladie = new Ajouter_Maladie();
            ajouter_maladie.ShowDialog();
        }

        private void symptômeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_symptome = new Ajouter_Symptome();
            ajouter_symptome.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                if (dataGridView1.CurrentCell.Value == dataGridView1.CurrentCell.Value)
                {
                    MySqlCommand description = new MySqlCommand();
                    MySqlCommand frequence = new MySqlCommand();
                    description.Connection = connection;
                    frequence.Connection = connection;
                    description.CommandText = "SELECT Description_Maladie FROM Maladie WHERE Nom_Maladie = '" + dataGridView1.CurrentCell.Value + "'";
                    frequence.CommandText = "UPDATE Maladie SET Frequence_Maladie=Frequence_Maladie+1 WHERE Nom_Maladie = '" + dataGridView1.CurrentCell.Value + "'";
                    connection.Open();
                    MySqlDataReader reader = description.ExecuteReader();
                    while (reader.Read())
                    {
                        MessageBox.Show(reader.GetString(0));
                    }

                    reader.Close();
                    frequence.ExecuteNonQuery();
                    connection.Close();
                }

            }
        }

        private void médicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_medicament = new Ajouter_Medicament();
            ajouter_medicament.ShowDialog();
        }
    }
}
