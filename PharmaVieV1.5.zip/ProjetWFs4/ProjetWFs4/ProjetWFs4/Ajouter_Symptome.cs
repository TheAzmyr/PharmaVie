﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Ajouter_Symptome : Form
    {
        MySqlConnection connection;

        MySqlCommand symptome = new MySqlCommand();
        
        public Ajouter_Symptome()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //connection = new MySqlConnection("server=10.101.0.1; database=projetb2s4; uid=root; pwd=rootroot");
            connection = new MySqlConnection("server=localhost; database=pharmavie; uid=root; pwd=");
            connection.Open();
            symptome.Connection = connection;
            symptome.CommandText = "INSERT INTO Symptome (Nom_Symptome) VALUES ('" + textBox1.Text + "')";

            try
            {
                symptome.ExecuteNonQuery();
                MessageBox.Show("Le symptome a bien été ajouté à la base de donnée");
            }
            catch(MySqlException ex)
            {
                MessageBox.Show("Erreur : " + ex);
            }
            connection.Close();
        }
    }
}
