﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetWFs4
{
    public partial class Accueil_Bibliotheque : Form
    {
        public Accueil_Bibliotheque()
        {
            InitializeComponent();
        }

        private void deconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            var accueil = new Accueil();
            accueil.Show();
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            var bibliotheque_maladie = new Accueil_Bibliotheque_Maladie();
            bibliotheque_maladie.Show();
            this.Close();
        }

        private void maladieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_maladie = new Ajouter_Maladie();
            ajouter_maladie.ShowDialog();
        }

        private void symptômeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_symptome = new Ajouter_Symptome();
            ajouter_symptome.ShowDialog();
        }

        private void lbl_maladie_Click(object sender, EventArgs e)
        {
            var bibliotheque_maladie = new Accueil_Bibliotheque_Maladie();
            bibliotheque_maladie.Show();
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            var bibliotheque_medicament = new Accueil_Bibliotheque_Medicament();
            bibliotheque_medicament.Show();
            this.Close();
        }

        private void lbl_medicaments_Click(object sender, EventArgs e)
        {
            var bibliotheque_medicament = new Accueil_Bibliotheque_Medicament();
            bibliotheque_medicament.Show();
            this.Close();
        }
    }
}
