﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Accueil_Consultation : Form
    {
        MySqlConnection connection;
        public int nb_combo = 0;
        public Accueil_Consultation()
        {
            InitializeComponent();
        }

        private void Accueil_Consultation_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server=10.101.0.1; database=PharmaVie; uid=root; pwd=rootroot");
            //connection = new MySqlConnection("server=localhost; database=pharmavie; uid=root; pwd=");
            connection.Open();
            MySqlCommand requete = new MySqlCommand();
            requete.Connection = connection;
            requete.CommandText = "SELECT * FROM Symptome ORDER BY Nom_Symptome ASC";
            MySqlDataReader symptome = requete.ExecuteReader();
            while(symptome.Read())
            {
                ComboBox1.Items.Add(symptome["Nom_Symptome"]);
                ComboBox2.Items.Add(symptome["Nom_Symptome"]);
                ComboBox3.Items.Add(symptome["Nom_Symptome"]);
                ComboBox4.Items.Add(symptome["Nom_Symptome"]);
                ComboBox5.Items.Add(symptome["Nom_Symptome"]);
                ComboBox6.Items.Add(symptome["Nom_Symptome"]);
            }
            connection.Close();

            
        }

        private void Btn_return_Click(object sender, EventArgs e)
        {
            var accueil = new Accueil();
            accueil.Show();
            this.Close();
        }
        
        private void Btn_recherche_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            dataGridView1.Rows.Clear();
            connection.Open();
            MySqlCommand commande = new MySqlCommand();
            commande.Connection = connection;
            commande.CommandText = "SELECT DISTINCT Maladie.Nom_Maladie FROM Maladie LEFT JOIN Avoir_Symptome ON Maladie.Nom_Maladie = Avoir_Symptome.Nom_Maladie WHERE Avoir_Symptome.Nom_Symptome IN ('"+ComboBox1.Text+"', '"+ComboBox2.Text+"', '"+ComboBox3.Text+"', '"+ComboBox4.Text+"', '"+ComboBox5.Text+"', '"+ComboBox6.Text+"') AND Nombre_Symptome >= " + nb_combo+" ";
            MySqlDataReader symptome2 = commande.ExecuteReader();
            while(symptome2.Read())
            {
                dataGridView1.Rows.Add(symptome2["Nom_Maladie"]);
            }
            connection.Close();
        }

        private void DeconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox1.SelectedIndex != -1)
            {
                if(nb_combo < 1 )
                {
                    nb_combo++;
                }
                ComboBox2.Visible = true;
            }
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox2.SelectedIndex != -1)
            {
                if(nb_combo < 2)
                {
                    nb_combo++;
                }
                ComboBox3.Visible = true;
            }
        }

        private void ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox3.SelectedIndex != -1)
            {
                if (nb_combo < 3)
                {
                    nb_combo++;
                }
                ComboBox4.Visible = true;

            }
        }

        private void ComboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox4.SelectedIndex != -1)
            {
                if (nb_combo < 4)
                {
                    nb_combo++;
                }
                ComboBox5.Visible = true;
            }
        }

        private void ComboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox5.SelectedIndex != -1)
            {
                if (nb_combo < 5)
                {
                    nb_combo++;
                }
                ComboBox6.Visible = true;

            }
        }

        private void ComboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox6.SelectedIndex != -1)
            {
                if (nb_combo < 6)
                {
                    nb_combo++;
                }
            }
        }

        private void Btn_test_combo_Click(object sender, EventArgs e)
        {
            label3.Text = nb_combo.ToString();
        }

        private void RefreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            nb_combo = 0;
            ComboBox1.SelectedIndex = -1;
            ComboBox2.SelectedIndex = -1;
            ComboBox3.SelectedIndex = -1;
            ComboBox4.SelectedIndex = -1;
            ComboBox5.SelectedIndex = -1;
            ComboBox6.SelectedIndex = -1;
        }

        private void maladieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_maladie = new Ajouter_Maladie();
            ajouter_maladie.ShowDialog();
        }

        private void symptômeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_symptome = new Ajouter_Symptome();
            ajouter_symptome.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void médicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_medicament = new Ajouter_Medicament();
            ajouter_medicament.ShowDialog();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                if (dataGridView1.CurrentCell.Value == dataGridView1.CurrentCell.Value)
                {
                    MySqlCommand description = new MySqlCommand();
                    MySqlCommand frequence = new MySqlCommand();
                    description.Connection = connection;
                    frequence.Connection = connection;
                    description.CommandText = "SELECT Description_Maladie FROM Maladie WHERE Nom_Maladie = '" + dataGridView1.CurrentCell.Value + "'";
                    frequence.CommandText = "UPDATE Maladie SET Frequence_Maladie=Frequence_Maladie+1 WHERE Nom_Maladie = '" + dataGridView1.CurrentCell.Value + "'";
                    connection.Open();
                    MySqlDataReader desc = description.ExecuteReader();
                    while (desc.Read())
                    {
                        MessageBox.Show(desc.GetString(0));
                    }

                    desc.Close();
                   /* MySqlCommand medicament = new MySqlCommand();
                    medicament.Connection = connection;
                    medicament.CommandText = "SELECT Nom_Medicament FROM Soigner WHERE Nom_Maladie = '" + dataGridView1.CurrentCell.Value + "' GROUP BY Nom_Maladie";
                    MySqlDataReader medic = medicament.ExecuteReader();
                    while(medic.Read())
                    {
                        MessageBox.Show("Médicament(s) conseillé(s) : "+  medic.GetString(0));
                    }
                    medic.Close();*/
                    frequence.ExecuteNonQuery();
                    connection.Close();
                }

            }
        }
    }
}
