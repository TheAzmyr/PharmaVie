﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetWFs4
{
    public partial class Accueil_Bibliotheque_Medicament : Form
    {
        public Accueil_Bibliotheque_Medicament()
        {
            InitializeComponent();
        }

        private void déconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void maladieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_maladie = new Ajouter_Maladie();
            ajouter_maladie.ShowDialog();
        }

        private void symptômeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_symptome = new Ajouter_Symptome();
            ajouter_symptome.ShowDialog();
        }

        private void médicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_medicament = new Ajouter_Medicament();
            ajouter_medicament.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            var medicamentaz = new Accueil_Bibliotheque_Medicament_A_Z();
            medicamentaz.Show();
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            var medicamentaz = new Accueil_Bibliotheque_Medicament_A_Z();
            medicamentaz.Show();
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            var accueil_bibliotheque_medicament_princip_actif = new Accueil_Bibliotheque_Medicament_Princip_Actif();
            accueil_bibliotheque_medicament_princip_actif.Show();
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            var accueil_bibliotheque_medicament_princip_actif = new Accueil_Bibliotheque_Medicament_Princip_Actif();
            accueil_bibliotheque_medicament_princip_actif.Show();
            this.Close();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
