﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Ajouter_Medicament : Form
    {
        MySqlConnection connection;

        int ordonance;
        MySqlCommand laboratoire = new MySqlCommand();
        MySqlCommand substance = new MySqlCommand();
        MySqlCommand forme = new MySqlCommand();
        MySqlCommand administration = new MySqlCommand();
        MySqlCommand classe = new MySqlCommand();
        MySqlCommand remboursement = new MySqlCommand();

        public Ajouter_Medicament()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Ajouter_Medicament_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server=10.101.0.1; database=PharmaVie; uid=root; pwd=rootroot");
            //connection = new MySqlConnection("server=localhost; database=pharmavie; uid=root; pwd=");
            connection.Open();
            
            laboratoire.Connection = connection;
            laboratoire.CommandText = "SELECT * FROM Laboratoire ORDER BY Nom_Laboratoire ASC";

            substance.Connection = connection;
            substance.CommandText = "SELECT * FROM Substance ORDER BY Nom_Substance ASC";

            forme.Connection = connection;
            forme.CommandText = "SELECT * FROM Forme ORDER BY Nom_Forme ASC";

            administration.Connection = connection;
            administration.CommandText = "SELECT * FROM Administration ORDER BY Nom_Administration ASC";

            classe.Connection = connection;
            classe.CommandText = "SELECT * FROM Classe ORDER BY Nom_Classe";

            remboursement.Connection = connection;
            remboursement.CommandText = "SELECT * FROM TauxRemboursement ORDER BY ID_TauxRemboursement ASC";


            MySqlDataReader dr_laboratoire = laboratoire.ExecuteReader();
            while(dr_laboratoire.Read())
            {
                comboBox1.Items.Add(dr_laboratoire["Nom_Laboratoire"]);
            }
            dr_laboratoire.Close();

            MySqlDataReader dr_substance = substance.ExecuteReader();
            while (dr_substance.Read())
            {
                comboBox2.Items.Add(dr_substance["Nom_Substance"]);
            }
            dr_substance.Close();

            MySqlDataReader dr_forme = forme.ExecuteReader();
            while (dr_forme.Read())
            {
                comboBox3.Items.Add(dr_forme["Nom_Forme"]);
            }
            dr_forme.Close();

            MySqlDataReader dr_administration = administration.ExecuteReader();
            while (dr_administration.Read())
            {
                comboBox4.Items.Add(dr_administration["Nom_Administration"]);
            }
            dr_administration.Close();

            MySqlDataReader dr_classe = classe.ExecuteReader();
            while (dr_classe.Read())
            {
                comboBox5.Items.Add(dr_classe["Nom_Classe"]);
            }
            dr_classe.Close();

            MySqlDataReader dr_remboursement = remboursement.ExecuteReader();
            while (dr_remboursement.Read())
            {
                comboBox6.Items.Add(dr_remboursement["ID_TauxRemboursement"]);
            }
            dr_remboursement.Close();

            connection.Close();
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox7.Text == "Oui")
            {
                ordonance = 1;
            }
            else
            {
                ordonance = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            MySqlCommand ajouter_medicament = new MySqlCommand();
            ajouter_medicament.Connection = connection;
            ajouter_medicament.CommandText = "INSERT INTO Medicament (Nom_Medicament, Posologie_Medicament, Nom_Laboratoire, Nom_Substance, Nom_Forme, Nom_Administration, Nom_Classe, Ordonance_Medicament, ID_TauxRemboursement) VALUES ('"+textBox1.Text+"', '"+textBox2.Text+"', '"+comboBox1.Text+"','"+comboBox2.Text+"','"+comboBox3.Text+"', '"+comboBox4.Text+"', '"+comboBox5.Text+"', "+ordonance+ ", " + comboBox6.Text + ")";
            try
            {
                ajouter_medicament.ExecuteNonQuery();
                MessageBox.Show("Le Médicament a bien été ajouté !");
            }
            catch(MySqlException ex)
            {
                MessageBox.Show("Erreur SQL : " + ex);
            }
            connection.Close();

        }
    }
}
