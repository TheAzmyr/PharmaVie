﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Accueil : Form
    {
        public Accueil()
        {
            InitializeComponent();
        }

        private void Accueil_Load(object sender, EventArgs e)
        {
           
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            var accueil_consultation = new Accueil_Consultation();
            accueil_consultation.Show();
            this.Close();
        }

        private void deconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            var accueil_bibliotheque = new Accueil_Bibliotheque();
            accueil_bibliotheque.Show();
            this.Close();
        }

        private void lbl_consultation_Click(object sender, EventArgs e)
        {
            var accueil_consultation = new Accueil_Consultation();
            accueil_consultation.Show();
            this.Close();
        }

        private void lbl_biblio_Click(object sender, EventArgs e)
        {
            var accueil_bibliotheque = new Accueil_Bibliotheque();
            accueil_bibliotheque.Show();
            this.Close();
        }

        private void symptômeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_symptome = new Ajouter_Symptome();
            ajouter_symptome.ShowDialog();
        }

        private void maladieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_maladie = new Ajouter_Maladie();
            ajouter_maladie.ShowDialog();
        }

        private void médicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_medicament = new Ajouter_Medicament();
            ajouter_medicament.ShowDialog();    
        }
    }
}
