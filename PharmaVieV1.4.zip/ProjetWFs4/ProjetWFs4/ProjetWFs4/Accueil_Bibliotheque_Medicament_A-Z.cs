﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Accueil_Bibliotheque_Medicament_A_Z : Form
    {
        MySqlConnection connection;

        public Accueil_Bibliotheque_Medicament_A_Z()
        {
            InitializeComponent();
        }

        private void Accueil_Bibliotheque_Medicament_A_Z_Load(object sender, EventArgs e)
        {
            //connection = new MySqlConnection("server=10.101.0.1; database=PharmaVie; uid=root; pwd=rootroot");
            connection = new MySqlConnection("server=localhost; database=pharmavie; uid=root; pwd=");
            connection.Open();
            MySqlCommand medicamentaz = new MySqlCommand();
            medicamentaz.Connection = connection;
            medicamentaz.CommandText = "SELECT * FROM medicament ORDER BY Nom_Medicament ASC";
            MySqlDataReader reader = medicamentaz.ExecuteReader();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["Nom_Medicament"]);
            }
            connection.Close();
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            var accueil_bibliotheque_medicament = new Accueil_Bibliotheque_Medicament();
            accueil_bibliotheque_medicament.Show();
            this.Close();
        }

        private void déconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void maladieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_maladie = new Ajouter_Maladie();
            ajouter_maladie.ShowDialog();
        }

        private void symptômeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_symptome = new Ajouter_Symptome();
            ajouter_symptome.ShowDialog();
        }

        private void médicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ajouter_medicament = new Ajouter_Medicament();
            ajouter_medicament.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            connection.Open();
            dataGridView1.Rows.Clear();
            MySqlCommand requete = new MySqlCommand();
            requete.Connection = connection;
            requete.CommandText = "SELECT * FROM medicament WHERE Nom_Medicament LIKE '%" + textBox1.Text + "%'";
            MySqlDataReader medicament_recherche = requete.ExecuteReader();
            while (medicament_recherche.Read())
            {
                dataGridView1.Rows.Add(medicament_recherche["Nom_Medicament"]);
            }
            connection.Close();
        }
    }
}
