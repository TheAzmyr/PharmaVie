﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetWFs4
{
    public partial class Accueil_Bibliotheque_Maladie : Form
    {
        public Accueil_Bibliotheque_Maladie()
        {
            InitializeComponent();
        }

        private void deconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            var accueil_bibliotheque = new Accueil_Bibliotheque();
            accueil_bibliotheque.Show();
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            var maladie_a_z = new Accueil_Bibliotheque_Maladie_A_Z();
            maladie_a_z.Show();
            this.Close();
        }

    }
}
