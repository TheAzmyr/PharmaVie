﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [user] VARCHAR(32) NULL, 
    [pass] VARCHAR(32) NULL
)
