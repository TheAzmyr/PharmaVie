﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("server=10.101.0.1; database=PharmaVie; uid=Marius; pwd=Marius1998%");
            connection.Open();
            MySqlDataAdapter sda = new MySqlDataAdapter("Select count(*) From identifiants where user='" + txtbox_user.Text + "' AND password='" + txtbox_mdp.Text + "'", connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows[0][0].ToString() == "1")
            {
                MessageBox.Show("Connexion établie", "Login");
                this.Hide();
                var accueil = new Accueil();
                accueil.Show();
                
            }
            else
            {
                MessageBox.Show("Identifiants incorrect ! Réessayez.", "Erreur");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
