﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Ajouter_Maladie : Form
    {
        MySqlConnection connection;
        public int nb_combo = 0;

        MySqlCommand requete_symptome1 = new MySqlCommand();
        MySqlCommand requete_symptome2 = new MySqlCommand();
        MySqlCommand requete_symptome3 = new MySqlCommand();
        MySqlCommand requete_symptome4 = new MySqlCommand();
        MySqlCommand requete_symptome5 = new MySqlCommand();
        MySqlCommand requete_symptome6 = new MySqlCommand();

        public Ajouter_Maladie()
        {
            InitializeComponent();
        }


        private void Ajouter_Maladie_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server=10.101.0.1; database=PharmaVie; uid=root; pwd=rootroot");
            connection.Open();
            MySqlCommand requete = new MySqlCommand();
            requete.Connection = connection;
            requete.CommandText = "SELECT * FROM Symptome ORDER BY Nom_Symptome ASC";
            MySqlDataReader symptome = requete.ExecuteReader();
            while (symptome.Read())
            {
                ComboBox1.Items.Add(symptome["Nom_Symptome"]);
                ComboBox2.Items.Add(symptome["Nom_Symptome"]);
                ComboBox3.Items.Add(symptome["Nom_Symptome"]);
                ComboBox4.Items.Add(symptome["Nom_Symptome"]);
                ComboBox5.Items.Add(symptome["Nom_Symptome"]);
                ComboBox6.Items.Add(symptome["Nom_Symptome"]);
            }
            connection.Close();
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox1.SelectedIndex != -1)
            {
                if (nb_combo < 1)
                {
                    nb_combo++;
                }
                
                ComboBox2.Visible = true;
            }
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox2.SelectedIndex != -1)
            {
                if (nb_combo < 2)
                {
                    nb_combo++;
                }
                ComboBox3.Visible = true;
            }
        }

        private void ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox3.SelectedIndex != -1)
            {
                if (nb_combo < 3)
                {
                    nb_combo++;
                }
                ComboBox4.Visible = true;

            }
        }

        private void ComboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox4.SelectedIndex != -1)
            {
                if (nb_combo < 4)
                {
                    nb_combo++;
                }
                ComboBox5.Visible = true;
            }
        }

        private void ComboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox5.SelectedIndex != -1)
            {
                if (nb_combo < 5)
                {
                    nb_combo++;
                }
                ComboBox6.Visible = true;

            }
        }

        private void ComboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox6.SelectedIndex != -1)
            {
                if (nb_combo < 6)
                {
                    nb_combo++;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
               
                MySqlCommand symptome2 = new MySqlCommand();
                symptome2.Connection = connection;
                symptome2.CommandText = "INSERT INTO Maladie (Nom_Maladie, Traitement_Maladie, Nombre_Symptome) VALUES ('" + textBox1.Text + "', '" + textBox2.Text + "', " + nb_combo + ")";
                // Symptome 1
                requete_symptome1.Connection = connection;
                requete_symptome1.CommandText = "INSERT INTO Avoir_Symptome (Nom_Maladie, Nom_Symptome) VALUES ('" + textBox1.Text + "', '" + ComboBox1.Text + "')";

            // Symptome 2
            requete_symptome2.Connection = connection;
            requete_symptome2.CommandText = "INSERT INTO Avoir_Symptome (Nom_Maladie, Nom_Symptome) VALUES ('" + textBox1.Text + "', '" + ComboBox1.Text + "'), ('" + textBox1.Text + "', '" + ComboBox2.Text + "')";

            // Symptome 3
            requete_symptome3.Connection = connection;
            requete_symptome3.CommandText = "INSERT INTO Avoir_Symptome (Nom_Maladie, Nom_Symptome) VALUES ('" + textBox1.Text + "', '" + ComboBox1.Text + "'), ('" + textBox1.Text + "', '" + ComboBox2.Text + "'), ('" + textBox1.Text + "', '" + ComboBox3.Text + "')";
            // Symptome 4
            requete_symptome4.Connection = connection;
            requete_symptome4.CommandText = "INSERT INTO Avoir_Symptome (Nom_Maladie, Nom_Symptome) VALUES ('" + textBox1.Text + "', '" + ComboBox1.Text + "'), ('" + textBox1.Text + "', '" + ComboBox2.Text + "'), ('" + textBox1.Text + "', '" + ComboBox3.Text + "'), ('" + textBox1.Text + "', '" + ComboBox4.Text + "')";

            // Symptome 5
            requete_symptome5.Connection = connection;
            requete_symptome5.CommandText = "INSERT INTO Avoir_Symptome (Nom_Maladie, Nom_Symptome) VALUES ('" + textBox1.Text + "', '" + ComboBox1.Text + "'), ('" + textBox1.Text + "', '" + ComboBox2.Text + "'), ('" + textBox1.Text + "', '" + ComboBox3.Text + "'), ('" + textBox1.Text + "', '" + ComboBox4.Text + "'), ('" + textBox1.Text + "', '" + ComboBox5.Text + "')";

            // Symptome 6
            requete_symptome6.Connection = connection;
            requete_symptome6.CommandText = "INSERT INTO Avoir_Symptome (Nom_Maladie, Nom_Symptome) VALUES ('" + textBox1.Text + "', '" + ComboBox1.Text + "'), ('" + textBox1.Text + "', '" + ComboBox2.Text + "'), ('" + textBox1.Text + "', '" + ComboBox3.Text + "'), ('" + textBox1.Text + "', '" + ComboBox4.Text + "'), ('" + textBox1.Text + "', '" + ComboBox5.Text + "'), ('" + textBox1.Text + "', '" + ComboBox6.Text + "')";
            try
            {
                symptome2.ExecuteNonQuery();

                // symptome 1
                if (nb_combo == 1)
                {
                    requete_symptome1.ExecuteNonQuery();
                }

                // symptome 2
                if (nb_combo == 2)
                {
                    requete_symptome2.ExecuteNonQuery();
                }
                // symptome 3
                if (nb_combo == 3)
                {
                    requete_symptome3.ExecuteNonQuery();
                }
                // symptome 4
                if (nb_combo == 4)
                {
                    requete_symptome4.ExecuteNonQuery();
                }
                // symptome 5
                if (nb_combo == 5)
                {
                    requete_symptome5.ExecuteNonQuery();
                }
                // symptome 6
                if (nb_combo == 6)
                {
                    requete_symptome6.ExecuteNonQuery();
                }

                MessageBox.Show("La maladie a été ajoutée à la base de donnée !");
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erreur : " + ex);
            }
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label5.Text = nb_combo.ToString();
        }

    }
}
