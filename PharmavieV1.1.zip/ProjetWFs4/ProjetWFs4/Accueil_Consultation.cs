﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetWFs4
{
    public partial class Accueil_Consultation : Form
    {
        MySqlConnection connection;
        public int nb_combo = 0;
        public Accueil_Consultation()
        {
            InitializeComponent();
        }

        private void Accueil_Consultation_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server=10.101.0.1; database=projetb2s4; uid=Marius; pwd=Marius1998%");
            connection.Open();
            MySqlCommand requete = new MySqlCommand();
            requete.Connection = connection;
            requete.CommandText = "SELECT * FROM Symptome ORDER BY Nom_Symptome ASC";
            MySqlDataReader symptome = requete.ExecuteReader();
            while(symptome.Read())
            {
                ComboBox1.Items.Add(symptome["Nom_Symptome"]);
                ComboBox2.Items.Add(symptome["Nom_Symptome"]);
                ComboBox3.Items.Add(symptome["Nom_Symptome"]);
                ComboBox4.Items.Add(symptome["Nom_Symptome"]);
                ComboBox5.Items.Add(symptome["Nom_Symptome"]);
                ComboBox6.Items.Add(symptome["Nom_Symptome"]);
            }
            connection.Close();
        }

        private void Btn_return_Click(object sender, EventArgs e)
        {
            var accueil = new Accueil();
            accueil.Show();
            this.Close();
        }
        
        private void Btn_recherche_Click(object sender, EventArgs e)
        {
            
            dataGridView1.Rows.Clear();
            connection.Open();
            MySqlCommand commande = new MySqlCommand();
            commande.Connection = connection;
            commande.CommandText = "SELECT DISTINCT Maladie.Nom_Maladie FROM Maladie LEFT JOIN Avoir_Symptome ON Maladie.Nom_Maladie = Avoir_Symptome.Nom_Maladie WHERE Avoir_Symptome.Nom_Symptome IN ('"+ComboBox1.Text+"', '"+ComboBox2.Text+"', '"+ComboBox3.Text+"', '"+ComboBox4.Text+"', '"+ComboBox5.Text+"', '"+ComboBox6.Text+"') AND Nombre_Symptome >= " + nb_combo+" ";
            MySqlDataReader symptome2 = commande.ExecuteReader();
            while(symptome2.Read())
            {
                dataGridView1.Rows.Add(symptome2["Nom_Maladie"]);
            }
            connection.Close();
        }

        private void DeconnexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox1.SelectedIndex != -1)
            {
                if(nb_combo < 1 )
                {
                    nb_combo++;
                }
                ComboBox2.Visible = true;
            }
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox2.SelectedIndex != -1)
            {
                if(nb_combo < 2)
                {
                    nb_combo++;
                }
                ComboBox3.Visible = true;
            }
        }

        private void ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox3.SelectedIndex != -1)
            {
                if (nb_combo < 3)
                {
                    nb_combo++;
                }
                ComboBox4.Visible = true;

            }
        }

        private void ComboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox4.SelectedIndex != -1)
            {
                if (nb_combo < 4)
                {
                    nb_combo++;
                }
                ComboBox5.Visible = true;
            }
        }

        private void ComboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox5.SelectedIndex != -1)
            {
                if (nb_combo < 5)
                {
                    nb_combo++;
                }
                ComboBox6.Visible = true;

            }
        }

        private void ComboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBox6.SelectedIndex != -1)
            {
                if (nb_combo < 6)
                {
                    nb_combo++;
                }
            }
        }

        private void Btn_test_combo_Click(object sender, EventArgs e)
        {
            label3.Text = nb_combo.ToString();
        }

        private void RefreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            nb_combo = 0;
            ComboBox1.SelectedIndex = -1;
            ComboBox2.SelectedIndex = -1;
            ComboBox3.SelectedIndex = -1;
            ComboBox4.SelectedIndex = -1;
            ComboBox5.SelectedIndex = -1;
            ComboBox6.SelectedIndex = -1;
        }
    }
}
